# HanVpn

Официальный лендинг VPN-сервиса **HanVpn**.

Сайт ведёт пользователей в Telegram-бота: [@HanvpnHappbot](https://t.me/HanvpnHappbot)

## Как открыть локально

Просто открой файл `index.html` в браузере.
